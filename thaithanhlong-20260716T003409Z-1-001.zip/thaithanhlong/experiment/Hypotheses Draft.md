\# Hypotheses Draft — GPT-4o-Based Gherkin Acceptance Test Generation from User Stories

\*\*Date:\*\* 2026-06-07

\---

\#\# RQ1 — Semantic Similarity

\*\*RQ1:\*\* Does GPT-4o generate Gherkin acceptance test scenarios with Cosine Semantic Similarity ≥ 0.85 compared with expert-written Gherkin scenarios?

\#\#\# H0

μ\_similarity ≤ 0.85

GPT-4o does not achieve the required semantic similarity threshold of 0.85.

\#\#\# H1

μ\_similarity \> 0.85

GPT-4o achieves semantic similarity greater than 0.85.

\#\#\# Statistical Test

One-sample Wilcoxon Signed-Rank Test (α \= 0.05)

\---

\#\# RQ2 — Executable Rate

\*\*RQ2:\*\* Does GPT-4o generate executable Gherkin acceptance test scenarios with an executable rate ≥ 80%?

\#\#\# H0

p\_executable ≤ 0.80

The executable rate of generated Gherkin scenarios is at most 80%.

\#\#\# H1

p\_executable \> 0.80

The executable rate of generated Gherkin scenarios is greater than 80%.

\#\#\# Statistical Test

One-sided Binomial Test (α \= 0.05)

