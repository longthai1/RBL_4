# **Lý do Thiết kế Thí nghiệm – Sinh kiểm thử chấp nhận Gherkin từ User Stories bằng GPT-4o**

**Ngày:** 07-06-2026

**Nguồn khoảng trống:** SLR/gap-analysis.md

## **Bảng Quyết định**

| Quyết định | Giá trị | Nguồn |
| :---: | ----- | ----- |
| **LLM/Công cụ** | GPT-4o (temperature \= 0, zero-shot prompting) | GAP-T: cột Tool/LLM |
| **Dữ liệu** | User stories theo định dạng Connextra, thu thập từ các dự án kỹ nghệ phần mềm | GAP-D: cột Dataset |
| **Thước đo chính** | Cosine Semantic Similarity (Sentence-Transformer all-MiniLM-L6-v2) | GAP-M: cột Metric |
| **Thước đo phụ** | Executable Rate (Gherkin Parser) | GAP-M: cột Metric |
| **Loại baseline** | Chuyên gia con người (kịch bản Gherkin do chuyên gia viết) | So sánh RQ |
| **Ngưỡng RQ1** | Semantic Similarity ≥ 0.85 | Trường hợp 2 – tham chiếu từ nghiên cứu về semantic matching |
| **Ngưỡng RQ2** | Executable Rate ≥ 80% | Trường hợp 2 – tham chiếu từ giá trị correctness được báo cáo |
| **Cơ sở pipeline** | Comparative Analysis of LLM Tools for Automated Test Data Generation from BDD (2024) | Bảng minh chứng – Bài báo \#1 |

## **Lý do chọn ngưỡng**

### **Ngưỡng cho RQ1 – Semantic Similarity ≥ 0.85**

**Trường hợp 2: Ngưỡng tham chiếu từ nghiên cứu trước**

Các nghiên cứu cho thấy chất lượng ngữ nghĩa thường được đánh giá bằng độ tương đồng văn bản hoặc các thước đo liên quan. Dù chưa có nghiên cứu nào dùng trực tiếp Cosine Similarity ≥ 0.85, nhiều bài báo báo cáo chất lượng cao với BLEU, ROUGE và các thước đo completeness ngữ nghĩa.

Do đó, ngưỡng **0.85** được chọn như một chuẩn thực tế, đại diện cho mức độ tương đồng ngữ nghĩa mạnh giữa kịch bản Gherkin sinh ra và kịch bản do chuyên gia viết.

**Lý do:**

* Phổ biến trong nghiên cứu semantic matching.  
* Thể hiện mức độ đồng thuận cao nhưng vẫn khả thi.  
* Phù hợp để đánh giá mức độ tương đương ở cấp độ yêu cầu.

### **Ngưỡng cho RQ2 – Executable Rate ≥ 80%**

**Trường hợp 2: Ngưỡng tham chiếu từ nghiên cứu trước**

Một số nghiên cứu báo cáo độ chính xác cú pháp, tỷ lệ thực thi, hoặc chất lượng kiểm thử chấp nhận trên 80%.

Ví dụ:

* Bài báo \#2: Syntactic Accuracy \= 92%  
* Bài báo \#3: Execution Success Rate \= 81%  
* Bài báo \#4: Acceptance Match Rate \= 86%

Giá trị thấp nhất trong nhóm kết quả mạnh là khoảng 81%.

Do đó, ngưỡng **80%** được chọn làm mức tối thiểu chấp nhận cho kịch bản Gherkin có thể thực thi.

**Lý do:**

* Phù hợp với kết quả chất lượng công nghiệp đã báo cáo.  
* Đặt ra chuẩn thực tế.  
* Đảm bảo kịch bản sinh ra có thể sử dụng trong thực tế.

## **Giải thích Thiết kế**

Thiết kế được chọn trực tiếp giải quyết các khoảng trống nghiên cứu đã xác định.

### **Phù hợp GAP-T**

Văn liệu hiện tại ít đánh giá GPT-4o trong cấu hình zero-shot có thể tái lập. Do đó, GPT-4o được chọn làm công cụ chính.

### **Phù hợp GAP-M**

Phần lớn nghiên cứu dùng BLEU, ROUGE, Coverage hoặc Utility. Rất ít nghiên cứu đánh giá đồng thời chất lượng ngữ nghĩa và khả năng thực thi. Vì vậy, Semantic Similarity và Executable Rate được chọn làm thước đo chính.

### **Phù hợp GAP-D**

Văn liệu thiếu bộ dữ liệu chuẩn hóa dựa trên user stories định dạng Connextra. Do đó, Connextra user stories được chọn làm tập dữ liệu thí nghiệm để tăng khả năng tái lập và so sánh.

