# **Giả thuyết nghiên cứu**

## **Câu hỏi nghiên cứu 1 (RQ1)**

**RQ1:** Liệu GPT-4o với cấu hình zero-shot (temperature \= 0\) có sinh ra kịch bản kiểm thử chấp nhận Gherkin với độ tương đồng ngữ nghĩa ≥ 0.85 so với kịch bản Gherkin do chuyên gia viết?

### **Giả thuyết**

**Giả thuyết rỗng (H0₁)**  

μ\_similarity ≤ 0.85

GPT-4o không đạt ngưỡng tương đồng ngữ nghĩa 0.85.

**Giả thuyết thay thế (H1₁)**  

μ\_similarity \> 0.85

GPT-4o đạt độ tương đồng ngữ nghĩa lớn hơn 0.85.

### **Kiểm định thống kê**

* Phép kiểm định: One-sample Wilcoxon Signed-Rank Test  
* Mức ý nghĩa (α): 0.05

### **Quy tắc quyết định**

* Nếu p-value \< 0.05 → Bác bỏ H0₁ → Chấp nhận H1₁  
* Nếu p-value ≥ 0.05 → Không bác bỏ H0₁

### **Ví dụ diễn giải**

Giả sử độ tương đồng trung bình đạt 0.89 và kiểm định Wilcoxon cho p \= 0.021.

Vì 0.021 \< 0.05, bác bỏ H0₁.

**Kết luận:** Có đủ bằng chứng thống kê cho thấy GPT-4o đạt độ tương đồng ngữ nghĩa \> 0.85 khi sinh kịch bản Gherkin từ user stories.

## **Câu hỏi nghiên cứu 2 (RQ2)**

**RQ2:** Liệu GPT-4o có sinh ra kịch bản Gherkin có thể thực thi với tỷ lệ thực thi \> 80%?

### **Giả thuyết**

**Giả thuyết rỗng (H0₂)**  

p\_executable ≤ 0.80

Tỷ lệ thực thi của kịch bản Gherkin sinh ra tối đa là 80%.

**Giả thuyết thay thế (H1₂)**  

p\_executable \> 0.80

Tỷ lệ thực thi của kịch bản Gherkin sinh ra lớn hơn 80%.

### **Kiểm định thống kê**

* Phép kiểm định: One-sided Binomial Test  
* Tỷ lệ giả định (p₀): 0.80  
* Mức ý nghĩa (α): 0.05

### **Quy tắc quyết định**

* Nếu p-value \< 0.05 → Bác bỏ H0₂ → Chấp nhận H1₂  
* Nếu p-value ≥ 0.05 → Không bác bỏ H0₂

### **Ví dụ diễn giải**

Giả sử:

* Tổng số kịch bản sinh ra \= 100  
* Kịch bản thực thi được \= 88

Tỷ lệ thực thi \= 88%

Nếu kiểm định nhị thức cho p \= 0.018:

Vì 0.018 \< 0.05, bác bỏ H0₂.

**Kết luận:** Có đủ bằng chứng thống kê cho thấy GPT-4o đạt tỷ lệ thực thi \> 80%.

## **Câu hỏi nghiên cứu 3 (RQ3)**

**RQ3:** Liệu GPT-4o có sinh ra kịch bản Gherkin bao phủ ít nhất 85% tiêu chí chấp nhận trong user stories?

### **Giả thuyết**

**Giả thuyết rỗng (H0₃)**  

μ\_coverage ≤ 0.85

GPT-4o không đạt ngưỡng bao phủ tiêu chí chấp nhận 85%.

**Giả thuyết thay thế (H1₃)**  

μ\_coverage \> 0.85

GPT-4o đạt bao phủ tiêu chí chấp nhận \> 85%.

### **Kiểm định thống kê**

* Phép kiểm định: One-sample Wilcoxon Signed-Rank Test  
* Mức ý nghĩa (α): 0.05

### **Quy tắc quyết định**

* Nếu p-value \< 0.05 → Bác bỏ H0₃ → Chấp nhận H1₃  
* Nếu p-value ≥ 0.05 → Không bác bỏ H0₃

# **Tóm tắt**

| RQ | Thước đo | H0 | H1 | Phép kiểm định |
| :---: | ----- | ----- | ----- | ----- |
| **RQ1** | Semantic Similarity | μ ≤ 0.85 | μ \> 0.85 | Wilcoxon Signed-Rank Test |
| **RQ2** | Executable Rate | p ≤ 0.80 | p \> 0.80 | One-sided Binomial Test |
| **RQ3** | Acceptance Criteria Coverage | μ ≤ 0.85 | μ \> 0.85 | Wilcoxon Signed-Rank Test |

## **Mức ý nghĩa**

α \= 0.05

## **Kết quả kỳ vọng**

Nghiên cứu kỳ vọng GPT-4o sẽ:

* Đạt semantic similarity \> 0.85  
* Đạt executable rate \> 80%  
* Đạt acceptance-criteria coverage \> 85%

Do đó, kết quả kỳ vọng là chấp nhận H1₁, H1₂ và H1₃.

