# **Pipeline Thực Nghiệm – LLM-Based Gherkin Generation**

**Dựa trên bài báo:** Fernandes et al. (2025), *A Comparative Study of LLMs for Gherkin Generation*, SBES 2025\.

---

# **Tổng quan**

Nghiên cứu này nhằm đánh giá khả năng của GPT-4o trong việc tự động chuyển đổi mô tả test case bằng ngôn ngữ tự nhiên thành các kịch bản Gherkin phục vụ Behavior-Driven Development (BDD).

**Dẫn chứng từ bài báo:**

"This study adopts an experimental and exploratory methodology to evaluate the ability of state-of-the-art LLMs to generate BDD test scenarios in Gherkin syntax based on free-form natural language descriptions."

---

# **Bước 1 – Chuẩn bị Dataset**

## **Mô tả**

Thu thập khoảng 20–30 User Stories hoặc Test Descriptions có đầy đủ thông tin nghiệp vụ.

## **Dẫn chứng**

"The dataset comprises 1,286 real-world test cases written in natural language."

"After preprocessing, a sample of 10 cases was randomly drawn."

## **Áp dụng trong nghiên cứu**

* Thu thập khoảng 20–30 User Stories.  
* Loại bỏ dữ liệu:  
  * quá ngắn;  
  * mơ hồ;  
  * trùng lặp;  
  * không có Acceptance Criteria.

---

# **Bước 2 – Xây dựng Ground Truth**

## **Mô tả**

Mỗi User Story được chuyển đổi thủ công thành một Gherkin chuẩn bởi chuyên gia.

## **Dẫn chứng**

"These cases were manually converted into reference BDD scenarios using Gherkin syntax by a domain specialist."

## **Áp dụng trong nghiên cứu**

Ground Truth được dùng làm đáp án chuẩn để đánh giá các Gherkin do GPT-4o sinh ra.

---

# **Bước 3 – Thiết kế Prompt**

## **Mô tả**

Nghiên cứu đánh giá ba kỹ thuật Prompt:

* Zero-shot  
* One-shot  
* Few-shot

## **Dẫn chứng**

"Each model was evaluated using three prompting strategies: zero-shot, one-shot, and few-shot."

---

## **Prompt sử dụng**

Convert the following test case description into exactly one BDD scenario using strict Gherkin syntax.

## **Dẫn chứng**

"Convert the following test case description into exactly one BDD scenario using strict Gherkin syntax."

---

# **Bước 4 – Sinh Gherkin**

## **Mô tả**

Mỗi User Story được gửi đến GPT-4o để sinh Gherkin Scenario.

## **Dẫn chứng**

"Each LLM was prompted with the selected test cases."

## **Quy trình**

User Story

      ↓

Prompt

      ↓

GPT-4o

      ↓

Gherkin Scenario

---

# **Bước 5 – Đánh giá Độ chính xác**

## **Metric sử dụng**

METEOR Score.

## **Dẫn chứng**

"METEOR exhibited the strongest correlation with expert judgments."

## **Công thức**

METEOR\_avg \=

mean(

METEOR(generated\_i,

reference\_i)

)

Mục đích:

Đo độ tương đồng giữa:

* Gherkin sinh bởi GPT-4o;  
* Gherkin chuẩn của chuyên gia.

---

# **Bước 6 – Đánh giá Tính ổn định**

## **Mô tả**

Mỗi Prompt được thực hiện nhiều lần để đánh giá độ ổn định của mô hình.

## **Dẫn chứng**

"Each combination was repeated five times."

## **Chỉ số sử dụng**

* Mean  
* Standard Deviation (SD)  
* Coefficient of Variation (CV)

## **Công thức**

CV \=

SD

─── ×100%

Mean

CV càng nhỏ:

⇒ mô hình càng ổn định.

---

# **Bước 7 – Phân tích Thống kê**

## **Dẫn chứng**

"The normality of distributions was tested using the Shapiro-Wilk test."

"Variance homogeneity was verified with Bartlett's test."

"Repeated Measures ANOVA was applied."

## **Phương pháp**

1. Kiểm tra phân phối chuẩn:

Shapiro-Wilk Test

2. Kiểm tra đồng nhất phương sai:

Bartlett Test

3. So sánh kết quả giữa các Prompt:

Repeated Measures ANOVA

---

# **Pipeline Thực Nghiệm Hoàn Chỉnh**

Dataset Test Descriptions

            ↓

Preprocessing

            ↓

Ground Truth Construction

            ↓

Prompt Engineering

(Zero-shot / One-shot / Few-shot)

            ↓

GPT-4o

            ↓

Generate Gherkin Scenarios

            ↓

┌─────────────────────────┬─────────────────────────┐

│ Accuracy Evaluation      │ Stability Evaluation    │

│ METEOR Score             │ Mean, SD, CV            │

└─────────────────────────┴─────────────────────────┘

            ↓

Statistical Analysis

(Shapiro-Wilk \+ Bartlett \+ ANOVA)

            ↓

Research Conclusion

---

# **Thư viện sử dụng**

pip install openai

pip install nltk

pip install scipy

pip install evaluate

pip install bert-score

---

# **Kết luận**

Pipeline trên được xây dựng trực tiếp từ methodology của bài báo:

**Fernandes et al. (2025) – A Comparative Study of LLMs for Gherkin Generation**, trong đó:

* Đầu vào là mô tả test case bằng ngôn ngữ tự nhiên;  
* Đầu ra là Gherkin Scenario;  
* Chất lượng được đánh giá bằng METEOR;  
* Tính ổn định được đánh giá bằng Mean, SD và CV;  
* Kết quả được xác nhận bằng các kiểm định thống kê.

