# **Báo cáo Khoảng trống nghiên cứu – Sinh Gherkin & BDD bằng LLM**

**Bảng minh chứng:** N \= 14 bài báo

## **Các khoảng trống nghiên cứu đã xác định**

### **GAP-T (Công nghệ): Đánh giá hạn chế đối với LLM chuyên ngành Kỹ nghệ phần mềm và mô hình Agent-Based**

**Minh chứng:**  

Phần lớn các nghiên cứu sử dụng LLM tổng quát như GPT-3.5, GPT-4, GPT-4o, Claude, và Llama. Chỉ một nghiên cứu (Bài báo \#5) thử nghiệm cách tiếp cận agent-based. Không có nghiên cứu nào đánh giá các mô hình chuyên biệt cho Kỹ nghệ phần mềm như CodeLlama, DeepSeek-Coder, StarCoder2, hoặc các LLM định hướng mã khác cho việc sinh kịch bản Gherkin hay kiểm thử BDD.

### **GAP-M (Thước đo): Thiếu bộ tiêu chí đánh giá chuẩn hóa cho chất lượng Gherkin**

**Minh chứng:**  

Các nghiên cứu sử dụng nhiều loại thước đo khác nhau: BLEU, ROUGE-L, Độ chính xác cú pháp, Độ đầy đủ ngữ nghĩa, Độ phủ nhánh, Điểm hữu ích do con người đánh giá, Precision, Recall, và F1-score. Tuy nhiên, chưa có khung đánh giá chung cho chất lượng kịch bản Gherkin, đặc biệt về mức độ bao phủ yêu cầu nghiệp vụ, tính dễ đọc, và khả năng thực thi.

### **GAP-D (Dữ liệu): Quy mô và đa dạng miền dữ liệu còn hạn chế**

**Minh chứng:**  

Nhiều nghiên cứu dựa trên tập dữ liệu nhỏ:

* 45 kịch bản BDD (Bài báo \#1)  
* 60 tệp tính năng BDD (Bài báo \#3)  
* 120 user stories (Bài báo \#2)  
* 15 dự án công nghiệp (Bài báo \#4)

Phần lớn dữ liệu tập trung vào các miền hẹp như thương mại điện tử, y tế, an toàn thực phẩm, hoặc hệ thống công nghiệp. Chỉ một số ít nghiên cứu dùng tập dữ liệu lớn như SelfBehave (10.000 ví dụ) và Huawei Datacom (89.316 mẫu). Việc thiếu các bộ dữ liệu chuẩn, đa miền và công khai hạn chế khả năng đánh giá tính tổng quát của mô hình.

## **Khoảng trống tổng thể**

Mặc dù các nghiên cứu gần đây cho thấy tiềm năng của LLM trong việc sinh kịch bản Gherkin và kiểm thử BDD từ user stories, vẫn còn thiếu các nghiên cứu đánh giá LLM chuyên ngành Kỹ nghệ phần mềm trên tập dữ liệu quy mô lớn, đa miền, với bộ tiêu chí đánh giá chuẩn hóa. Giải quyết khoảng trống này sẽ giúp nâng cao chất lượng, độ tin cậy và tính ứng dụng thực tiễn của hệ thống sinh kiểm thử tự động dựa trên LLM.

