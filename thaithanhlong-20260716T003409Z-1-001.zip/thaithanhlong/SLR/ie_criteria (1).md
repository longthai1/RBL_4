# **IE Criteria – LLM-Based Gherkin and BDD Test Generation**

**Thành viên:** Thai Thanh Long

**RQ:** "How are Large Language Models used to generate Gherkin scenarios and BDD test cases from user stories, and how effective are these approaches?"

**PICO:**

* P \= Gherkin scenario generation / BDD test generation from user stories  
* I \= Large Language Models (GPT, ChatGPT, LLaMA, T5, BERT, etc.)  
* C \= Existing approaches, templates, or rule-based techniques  
* O \= Quality metrics (syntax correctness, semantic similarity, BLEU, accuracy, acceptance-test quality)

## **Inclusion Criteria (IC)**

IC-L | Viết bằng tiếng Anh

IC-Y | Xuất bản từ 2020 đến nay – Lý do: Các LLM hiện đại (GPT-3 trở lên) bắt đầu được sử dụng rộng rãi từ năm 2020

IC-T | Conference, journal hoặc workshop proceedings đã qua phản biện

IC-P | Nghiên cứu về sinh tự động Gherkin scenarios, BDD test cases, acceptance tests hoặc test cases từ user stories/requirements

IC-I | Sử dụng LLM, NLP hoặc AI-based techniques (GPT, ChatGPT, LLaMA, T5, BERT, Transformer-based models)

IC-E | Có ít nhất một kết quả thực nghiệm hoặc chỉ số định lượng (BLEU, Accuracy, Precision, Recall, Semantic Similarity, Syntax Correctness, User Evaluation...)

## **Exclusion Criteria (EC)**

EC-D | Trùng lặp với paper đã thu thập

EC-A | Không truy cập được full-text

EC-S | Bài ngắn dưới 4 trang, poster, tutorial hoặc extended abstract

EC-N | Không có thực nghiệm, không có đánh giá định lượng hoặc case study

EC-O | Không liên quan đến chủ đề nghiên cứu, ví dụ:

* Chỉ tập trung vào code generation  
* Chỉ tập trung vào defect prediction  
* Chỉ tập trung vào software maintenance  
* Chỉ tập trung vào test execution  
* Chỉ tập trung vào IoT, networking hoặc các lĩnh vực ngoài software testing

