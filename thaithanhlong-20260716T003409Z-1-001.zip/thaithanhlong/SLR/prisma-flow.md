# **PRISMA Flow Diagram**

\[Records identified through database searching (N \= 49)\]

* Google Scholar – String A (N \= 26\)  
* Google Scholar – String B (N \= 23\)

↓

\[Records after duplicates removed (N \= 49)\]

↓

┌───────────────────────────────────────────────┐  
│ Records screened (Title \+ Abstract) (N \= 49\) │  
│ │  
│ Excluded (N \= 24\) │  
│ \- EC-O \= 21 │  
│ \- EC-N \= 3 │  
└───────────────────────────────────────────────┘

↓

\[Records for full-text assessment (N \= 25)\]

↓

┌───────────────────────────────────────────────┐  
│ Full-text articles assessed (N \= 25\) │  
│ │  
│ Excluded after full-text (N \= 12\) │  
│ \- EC4 \= 4 │  
│ \- EC5 \= 5 │  
│ \- EC6 \= 2 │  
│ \- EC1 \= 1 │  
└───────────────────────────────────────────────┘

↓

\[Studies included in final review (N \= 13)\]

