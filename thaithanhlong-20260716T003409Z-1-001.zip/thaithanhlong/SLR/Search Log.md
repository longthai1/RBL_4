# **Nhật ký Tìm kiếm – Sinh Gherkin và BDD bằng LLM**

**Sinh viên:** Thái Thành Long

**Ngày:** 03-06-2026

# **Chuỗi Tìm kiếm (Query Strings)**

## **Chuỗi A**

### **Truy vấn gốc**

("large language model" OR "LLM" OR "GPT" OR "ChatGPT")

AND

("Gherkin" OR "BDD")

AND

("user story" OR "requirements")

**Cơ sở dữ liệu:** Google Scholar

**Bộ lọc:**

* Năm: 2020–2026  
* Ngôn ngữ: Tiếng Anh  
* Loại: Hội nghị \+ Tạp chí

**Ngày tìm kiếm:** 03-06-2026

**Kết quả:** 14 bài báo

## **Chuỗi B**

### **Truy vấn gốc**

("large language model" OR "LLM")

AND

("acceptance test generation" OR "test case generation")

AND

("semantic similarity" OR "syntax correctness")

**Cơ sở dữ liệu:** Google Scholar

**Bộ lọc:**

* Năm: 2020–2026  
* Ngôn ngữ: Tiếng Anh  
* Loại: Hội nghị \+ Tạp chí

**Ngày tìm kiếm:** 03-06-2026

**Kết quả:** 15 bài báo

# **Tóm tắt trước khi loại trùng lặp**

| Cơ sở dữ liệu | Chuỗi | Kết quả |
| :---: | ----- | ----- |
| **Google Scholar** | Chuỗi A | 14 |
| **Google Scholar** | Chuỗi B | 15 |
| **Tổng trước loại trùng** |  | **29** |

# **Loại trùng lặp**

| Mục | Số lượng |
| :---: | ----- |
| **Tổng trước loại trùng** | 29 |
| **Bản trùng bị loại** | 0 |
| **Hồ sơ sau loại trùng** | 29 |

Xuất ra:

`01_all_records.csv`

# **Giai đoạn 1 – Sàng lọc tiêu đề và tóm tắt**

| Quyết định | Số lượng |
| :---: | ----- |
| **INCLUDE (Bao gồm)** | 12 |
| **UNSURE (Chưa chắc)** | 1 |
| **EXCLUDE (Loại bỏ)** | 16 |
| **Tổng** | 29 |

Xuất ra:

`02_after_screening_v1.csv`

# **Giai đoạn 2 – Sàng lọc toàn văn**

Chỉ các bài được đánh dấu **INCLUDE** hoặc **UNSURE** ở Giai đoạn 1 được đánh giá.

| Mục | Số lượng |
| :---: | ----- |
| **Toàn văn được đánh giá** | 13 |
| **Loại bỏ sau đánh giá toàn văn** | 4 |
| **Nghiên cứu cuối cùng được chọn** | 9 |

Xuất ra:

`03_final_included.csv`

# **Tìm kiếm tham chiếu chéo (Snowballing)**

**Phương pháp:** Backward Snowballing

**Quy trình:**  

Tham khảo của tất cả các nghiên cứu được chọn được kiểm tra thủ công để tìm thêm bài liên quan.

**Công cụ sử dụng:**

* Google Scholar  
* Crossref

**Ngày thực hiện:** 04-06-2026

**Số bài đã quét:** 9

**Bài bổ sung tìm thấy:** 0

**Bài bổ sung được chọn:** 0

Không có bài nào thỏa tiêu chí bổ sung.

# **Ghi chú**

**Phương pháp loại trùng:** Thực hiện thủ công bằng Microsoft Excel.

**Kết quả Snowballing:** Không tìm thấy thêm bài báo.

**Quan sát:**

* Các nghiên cứu liên quan chủ yếu xuất bản từ 2024–2026.  
* Google Scholar cung cấp phạm vi bao phủ đủ cho chủ đề này.  
* Không phát hiện bản ghi trùng lặp giữa hai chuỗi truy vấn.

# **Kiểm tra tính nhất quán**

| Kiểm tra | Giá trị |
| :---: | ----- |
| **Hồ sơ sau loại trùng** | 29 |
| **Số dòng trong 01\_all\_records.csv** | 29 |
| **Loại bỏ ở V1** | 16 |
| **INCLUDE \+ UNSURE ở V1** | 13 |
| **Toàn văn được đánh giá** | 13 |
| **Loại bỏ ở V2** | 4 |
| **Nghiên cứu cuối cùng được chọn** | 9 |

Tất cả số liệu nhất quán giữa nhật ký tìm kiếm và các tệp sàng lọc.

