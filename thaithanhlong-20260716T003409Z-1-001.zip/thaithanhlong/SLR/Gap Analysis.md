# **Phân tích Khoảng trống – Sinh Gherkin và BDD bằng LLM**

**Bảng minh chứng:** N \= 14 bài báo

## **Các khoảng trống đã xác định**

### **GAP-T (Công nghệ)**

**Mô tả:**  

Phần lớn nghiên cứu đánh giá GPT-3.5, GPT-4, Claude, Llama, PaLM hoặc các LLM tùy chỉnh. Rất ít nghiên cứu xem xét GPT-4o, và chưa có bài báo nào đánh giá một cách hệ thống GPT-4o với cấu hình zero-shot có thể tái lập (temperature \= 0\) cho việc sinh kiểm thử chấp nhận Gherkin.

**Minh chứng:**

* GPT-3.5: Bài báo \#1, \#7, \#11, \#12  
* GPT-4: Bài báo \#1, \#3, \#4, \#6, \#10  
* Claude: Bài báo \#2, \#6  
* Llama: Bài báo \#1, \#2, \#4  
* GPT-4o: Chỉ xuất hiện trong Bài báo \#2 và \#5

Do đó, GPT-4o vẫn chưa được khai thác đầy đủ so với các mô hình GPT trước đó.

### **GAP-M (Thước đo)**

**Mô tả:**  

Phần lớn nghiên cứu tập trung vào BLEU, ROUGE, Coverage, Accuracy, Utility Score, Precision, Recall, và F1-score. Rất ít nghiên cứu đánh giá độ tương đồng ngữ nghĩa giữa kịch bản Gherkin sinh ra và kịch bản do chuyên gia viết, và tỷ lệ thực thi (executable rate) hầu như không được báo cáo.

**Minh chứng:**

* BLEU, ROUGE-L: Bài báo \#1  
* Độ chính xác cú pháp: Bài báo \#2  
* Độ phủ nhánh: Bài báo \#3  
* Điểm hữu ích: Bài báo \#4  
* Đánh giá con người: Bài báo \#6  
* F1-score: Bài báo \#9 và \#13

Không có nghiên cứu nào sử dụng đồng thời:

* Cosine Semantic Similarity  
* Executable Rate

như thước đo chính.

### **GAP-D (Dữ liệu)**

**Mô tả:**  

Phần lớn nghiên cứu dựa trên tập dữ liệu nhỏ hoặc đặc thù miền, hạn chế khả năng tổng quát hóa và tái lập.

**Minh chứng:**

* 45 kịch bản BDD (Bài báo \#1)  
* 60 tệp tính năng BDD (Bài báo \#3)  
* 120 user stories (Bài báo \#2)  
* 15 dự án công nghiệp (Bài báo \#4)

Các miền dữ liệu chủ yếu:

* Y tế  
* Thương mại điện tử  
* An toàn thực phẩm  
* Phần mềm công nghiệp  
* Viễn thông

Không có nghiên cứu nào sử dụng bộ dữ liệu chuẩn hóa từ user stories theo định dạng Connextra.

### **GAP-S (Hạn chế chung)**

**Mô tả:**  

Một hạn chế phổ biến được báo cáo là quy mô dữ liệu nhỏ và thiếu đa dạng miền.

**Minh chứng:**  

Các bài báo nêu rõ hạn chế này: \#1, \#2, \#4, \#6, \#7, \#9, \#13.

Tổng cộng 7/14 bài báo có cùng hạn chế.

## **Khoảng trống nghiên cứu được chọn**

### **Khoảng trống chính**

**GAP-T (Công nghệ)**  

Hiệu quả của GPT-4o trong việc sinh kiểm thử chấp nhận Gherkin chưa được đánh giá một cách hệ thống với cấu hình zero-shot có thể tái lập.

### **Khoảng trống phụ**

**GAP-M (Thước đo)**  

Việc kết hợp Cosine Semantic Similarity và Executable Rate để đánh giá kịch bản Gherkin sinh ra vẫn chưa được khai thác.

## **Tuyên bố Khoảng trống cuối cùng**

Mặc dù các nghiên cứu trước đây đã chứng minh tiềm năng của LLM trong tự động hóa BDD và Gherkin, nhưng vẫn còn thiếu nghiên cứu đánh giá hệ thống GPT-4o với cấu hình zero-shot có thể tái lập. Bên cạnh đó, các thước đo về độ tương đồng ngữ nghĩa và tỷ lệ thực thi hiếm khi được sử dụng đồng thời, khiến chất lượng thực tiễn của kịch bản Gherkin sinh ra chưa được đánh giá đầy đủ.

