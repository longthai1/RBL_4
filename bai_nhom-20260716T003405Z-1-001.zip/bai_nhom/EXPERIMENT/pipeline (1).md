# **Pipeline Thực Nghiệm – LLM-Based Gherkin Generation**

---

# **Tổng quan**

Pipeline thực nghiệm này được xây dựng dựa trên nghiên cứu:

**Karpurapu et al. (2024), "Comprehensive Evaluation and Insights Into the Use of Large Language Models in the Automation of Behavior-Driven Development Acceptance Test Formulation", IEEE Access.**

Nghiên cứu đề xuất sử dụng các mô hình ngôn ngữ lớn (LLMs) để tự động sinh BDD Acceptance Tests từ Agile User Stories và đánh giá chất lượng của các kịch bản Gherkin được tạo ra.

---

# **Bước 1 – Chuẩn bị Dataset (Input)**

## **Dẫn chứng từ bài báo**

"For this study, we curated a diverse set of approximately 50 real-world user stories drawn from various sources."

"The data sources include user story data from Mendeley and a blog post."

## **Dataset sử dụng trong nghiên cứu**

Trong phạm vi đồ án, sử dụng khoảng **20–30 Agile User Stories** có đầy đủ Acceptance Criteria.

### **Tiêu chí lựa chọn**

✅ Có cấu trúc:

As a \[role\],  
I want \[feature\],  
so that \[benefit\].

✅ Có ít nhất một Acceptance Criteria.

✅ Nội dung rõ ràng, không mơ hồ.

❌ Loại bỏ User Story quá ngắn.

❌ Loại bỏ User Story quá phức tạp (\>5 Acceptance Criteria).

---

## **Ground Truth**

Đối với mỗi User Story, một kịch bản Gherkin chuẩn được xây dựng thủ công bởi chuyên gia để dùng làm đáp án tham chiếu.

Ví dụ:

Scenario: Successful Login  
Given customer is registered  
When customer enters valid credentials  
Then access is granted

---

# **Bước 2 – Thiết kế Prompt (Prompt Engineering)**

## **Dẫn chứng từ bài báo**

"We evaluated zero and few-shot prompt techniques."

"The few-shot prompt includes additional BDD scenario examples."

---

## **Chiến lược Prompt**

### **Zero-shot Prompt**

Bạn là chuyên gia BDD.

Hãy sinh kịch bản Gherkin từ User Story sau.

---

### **Few-shot Prompt**

Cung cấp 2–3 ví dụ:

User Story  
↓  
Gherkin Scenario

để mô hình học theo ngữ cảnh (In-Context Learning).

---

### **Chain-of-Thought**

Trước khi sinh Gherkin, mô hình thực hiện:

1. Xác định Actor.  
2. Xác định Feature.  
3. Xác định Given.  
4. Xác định When.  
5. Xác định Then.  
6. Sinh Scenario hoàn chỉnh.

---

# **Bước 3 – Sinh Gherkin (Output Generation)**

## **Dẫn chứng từ bài báo**

"Each user story description, accompanied by the prompt and model parameters, are sent in the request body to the model API endpoint."

"We store the model's BDD acceptance tests response as a .feature file."

---

## **Mô hình sử dụng**

GPT-4o-2024-05-13

## **Tham số**

temperature \= 0.2  
max\_tokens \= 500

## **Thực hiện**

Mỗi User Story được gửi đến GPT-4o API.

Kết quả được lưu dưới dạng:

.feature

Mỗi User Story được chạy **03 lần** nhằm đánh giá tính ổn định của mô hình.

---

# **Bước 4 – Kiểm tra Cú pháp Gherkin**

## **Dẫn chứng từ bài báo**

"The generated feature files undergo validation using a tool that validates Gherkin syntax."

"We employed the Gherkin-lint tool."

---

## **Công cụ sử dụng**

* Gherkin-Lint  
* Behave Parser

---

## **Metric 1 – Syntax Accuracy**

Công thức được sử dụng trong bài báo:

Validation Accuracy \=  
(Number of Feature Files without Syntax Errors)  
/  
(Total Number of Generated Feature Files)  
×100%

---

## **Giả thuyết nghiên cứu**

### **H0₁**

Syntax Accuracy ≥ 92%

---

# **Bước 5 – Đánh giá Ngữ nghĩa**

Mục tiêu là so sánh:

Gherkin do GPT-4o sinh ra

với

Gherkin chuẩn của chuyên gia.

---

## **Metric 2 – BLEU Score**

BLEU\_avg \=  
mean(  
BLEU(generated\_i,  
expert\_i)  
)

---

## **Giả thuyết nghiên cứu**

### **H0₂**

BLEU ≥ 0.7670

---

# **Bước 6 – Kiểm định Thống kê**

| Giả thuyết | Kiểm định |
| ----- | ----- |
| H0₁ | Binomial Exact Test |
| H0₂ | One-Sample Wilcoxon Signed-Rank Test |

---

## **Mức ý nghĩa**

α \= 0.05

Quy tắc:

Nếu p-value \< 0.05  
⇒ Bác bỏ giả thuyết H0.

---

# **Tóm tắt Pipeline**

Agile User Stories (.csv)  
            ↓  
Prompt Engineering  
(Zero-shot / Few-shot \+ CoT)  
            ↓  
GPT-4o  
            ↓  
Sinh Gherkin (.feature)  
            ↓  
┌────────────────────┬────────────────────┐  
│ Kiểm tra cú pháp    │ Đánh giá ngữ nghĩa │  
│ Gherkin-Lint        │ BLEU Score         │  
│ PASS / FAIL         │ 0.0 – 1.0          │  
└────────────────────┴────────────────────┘  
            ↓  
Kiểm định thống kê  
(Binomial \+ Wilcoxon)  
            ↓  
Kết luận nghiên cứu

---

# **Thư viện sử dụng**

pip install openai  
pip install nltk  
pip install behave  
pip install scipy  
pip install gherkin-lint

| Thư viện | Mục đích |
| ----- | ----- |
| openai | Gọi GPT-4o API |
| nltk | Tính BLEU Score |
| behave | Parse Gherkin |
| scipy.stats | Kiểm định thống kê |
| gherkin-lint | Kiểm tra lỗi cú pháp |

