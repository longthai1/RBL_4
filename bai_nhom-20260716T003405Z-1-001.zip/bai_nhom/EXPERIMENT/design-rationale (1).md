# **Experiment Design Rationale – GPT-4o Zero-Shot Gherkin Generation from User Stories**

Ngày: 2026-06-11  
GAP source: SLR/gap-analysis.md

## **Bảng Quyết Định**

| Quyết định | Giá trị | Nguồn gốc |
| ----- | ----- | ----- |
| LLM/Tool | GPT-4o (Zero-Shot Prompting) | GAP-T: Chưa có nghiên cứu đánh giá GPT-4o zero-shot cho Gherkin generation |
| Dataset | Public User Stories Dataset (\~50 User Stories từ GitHub Agile Projects) | GAP-D: Hầu hết nghiên cứu dùng dataset nội bộ hoặc số lượng nhỏ |
| Metric chính | BLEU Score (NLTK BLEU) | GAP-M: Chưa có nghiên cứu đánh giá bằng BLEU |
| Metric phụ | Syntax Correctness (%) | Kế thừa từ Karpurapu et al., 2024 |
| Baseline type | Threshold | RQ thuộc dạng Absolute Threshold Claim |
| Threshold RQ1 | BLEU ≥ 0.70 | Case 2: dựa trên mức chất lượng cao thường dùng trong text generation |
| Threshold RQ2 | Syntax Correctness ≥ 90% | Case 2: tham khảo kết quả GPT-3.5/GPT-4 trong Karpurapu et al., 2024 |
| Pipeline base | Ferreira et al., 2025 | Quy trình User Story → Gherkin phù hợp nhất với đề tài |

---

## **Pipeline Thực Nghiệm**

### **Bước 1**

Thu thập tập User Stories từ các dự án Agile công khai trên GitHub.

### **Bước 2**

Xây dựng tập Ground Truth Gherkin tương ứng.

### **Bước 3**

Gửi User Story vào GPT-4o bằng Zero-Shot Prompting.

### **Bước 4**

Thu nhận Gherkin Scenario do GPT-4o sinh ra.

### **Bước 5**

So sánh với Ground Truth bằng BLEU Score.

### **Bước 6**

Kiểm tra tính hợp lệ cú pháp Gherkin (Given-When-Then).

### **Bước 7**

Tính BLEU trung bình và Syntax Correctness.

---

## **Lý giải Threshold**

### **Threshold BLEU ≥ 0.70**

Case 2 – Không có paper nào trong evidence table đề xuất trực tiếp ngưỡng BLEU cho Gherkin generation.

Các nghiên cứu hiện tại chủ yếu đánh giá bằng correctness, usefulness hoặc expert judgement. Vì vậy ngưỡng BLEU \= 0.70 được chọn làm floor value cho mức tương đồng cao giữa Gherkin sinh ra và Ground Truth. Trong các nghiên cứu NLP và text generation, BLEU từ 0.70 trở lên thường được xem là chất lượng tốt và đủ để sử dụng thực tế.

---

### **Threshold Syntax Correctness ≥ 90%**

Case 2 – Dựa trên kết quả của Karpurapu et al. (2024).

Nghiên cứu cho thấy GPT-3.5 và GPT-4 tạo acceptance tests với tỷ lệ đúng cú pháp rất cao và gần như không xuất hiện lỗi cấu trúc Gherkin. Do đó ngưỡng 90% được sử dụng làm mức tối thiểu để xác định GPT-4o có khả năng tạo Gherkin hợp lệ trong thực tế.

---

## **Lý do chọn GPT-4o**

Từ evidence table:

* Karpurapu et al. (2024): GPT-3.5, GPT-4  
* Ferreira et al. (2025): GPT-4 Turbo  
* Fernandes et al. (2025): GPT-4o Mini  
* Nettur et al. (2025): GPT-4o cho Cypress generation

Chưa có nghiên cứu đánh giá trực tiếp GPT-4o Zero-Shot trên bài toán sinh Gherkin từ User Stories.

Điều này tạo thành GAP-T rõ ràng và khả thi để thực hiện trong phạm vi môn học.

---

## **Kết nối với Research Question**

RQ:

"Can GPT-4o using zero-shot prompting generate Gherkin acceptance test cases from user stories with BLEU ≥ 0.70?"

P \= Public User Stories Dataset

I \= GPT-4o \+ Zero-Shot Prompting

C \= BLEU Threshold 0.70

O \= BLEU Score và Syntax Correctness

Thiết kế thực nghiệm trên cho phép trả lời trực tiếp Research Question và kiểm định giả thuyết nghiên cứu.

