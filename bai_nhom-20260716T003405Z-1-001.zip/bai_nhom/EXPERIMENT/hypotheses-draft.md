# **Hypotheses Draft – Sinh Gherkin Test Case từ User Story bằng GPT-4o**

Ngày: 2026-06-11

## **RQ1 – Hiệu quả sinh Gherkin bằng GPT-4o**

**RQ1:**  
"GPT-4o sử dụng chiến lược zero-shot prompting có sinh được Gherkin acceptance test case từ user story đạt BLEU ≥ 0.70 không?"

### **H0 (Giả thuyết không)**

Điểm BLEU trung bình của các Gherkin được GPT-4o sinh ra nhỏ hơn 0.70.

μBLEU \< 0.70

### **H1 (Giả thuyết nghiên cứu)**

Điểm BLEU trung bình của các Gherkin được GPT-4o sinh ra lớn hơn hoặc bằng 0.70.

μBLEU ≥ 0.70

**Kiểm định thống kê dự kiến:**  
One-Sample Wilcoxon Signed-Rank Test (α \= 0.05)

---

## **RQ2 – Độ đúng cú pháp Gherkin**

**RQ2:**  
"GPT-4o sử dụng zero-shot prompting có sinh được Gherkin đúng cú pháp với tỷ lệ ít nhất 90% không?"

### **H0 (Giả thuyết không)**

Tỷ lệ Gherkin đúng cú pháp do GPT-4o sinh ra nhỏ hơn 90%.

p \< 0.90

### **H1 (Giả thuyết nghiên cứu)**

Tỷ lệ Gherkin đúng cú pháp do GPT-4o sinh ra lớn hơn hoặc bằng 90%.

p ≥ 0.90

**Kiểm định thống kê dự kiến:**  
One-Sample Binomial Exact Test (α \= 0.05)

---

## **Biến nghiên cứu**

### **Biến độc lập (Independent Variable)**

* GPT-4o  
* Chiến lược Zero-Shot Prompting

### **Biến phụ thuộc (Dependent Variable)**

* Điểm BLEU  
* Tỷ lệ đúng cú pháp Gherkin (%)

### **Biến kiểm soát (Controlled Variables)**

* Cùng bộ User Stories  
* Cùng Prompt Template  
* Cùng phiên bản GPT-4o  
* Cùng quy trình đánh giá

---

## **Kết quả kỳ vọng**

Dựa trên các nghiên cứu trước như Karpurapu et al. (2024), Ferreira et al. (2025) và Fernandes et al. (2025), các mô hình GPT cho thấy hiệu quả cao trong việc sinh Acceptance Test và Gherkin Scenario.

Do đó nghiên cứu kỳ vọng:

* Điểm BLEU trung bình ≥ 0.70  
* Tỷ lệ đúng cú pháp Gherkin ≥ 90%

khi sử dụng GPT-4o với chiến lược Zero-Shot Prompting để sinh Gherkin Acceptance Test từ User Stories.

