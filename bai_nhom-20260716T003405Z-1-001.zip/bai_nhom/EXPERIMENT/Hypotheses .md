# **Hypotheses — LLM-based Gherkin Scenario Generation**

## **Null Hypothesis (H0)**

GPT-4o sử dụng Zero-Shot Prompting không thể sinh Gherkin Scenarios từ User Stories đạt BLEU Score ≥ 0.70 khi so sánh với Gherkin Scenarios do chuyên gia tạo.

## **Alternative Hypothesis (H1)**

GPT-4o sử dụng Zero-Shot Prompting có thể sinh Gherkin Scenarios từ User Stories đạt BLEU Score ≥ 0.70 khi so sánh với Gherkin Scenarios do chuyên gia tạo.

## **Decision Rule**

* Chấp nhận H1 nếu BLEU Score trung bình ≥ 0.70  
* Chấp nhận H0 nếu BLEU Score trung bình \< 0.70

## **Expected Result**

Dựa trên các nghiên cứu trước đây về GPT-4 và GPT-4 Turbo trong sinh Acceptance Tests và Gherkin Scenarios, kỳ vọng GPT-4o sẽ đạt BLEU Score từ 0.70 đến 0.85 trên tập User Stories thử nghiệm.

