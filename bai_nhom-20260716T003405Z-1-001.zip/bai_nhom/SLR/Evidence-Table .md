# **Evidence Table — LLM for Acceptance Test Automation (BDD/Gherkin)**

| Paper | Tool/LLM | Dataset | Metric | Result | Limitation |
| ----- | ----- | ----- | ----- | ----- | ----- |
| Karpurapu et al., 2024 (IEEE Access) | GPT-3.5, GPT-4, Llama-2-13B, PaLM-2 | BDD Acceptance Test Dataset | Syntax Correctness, Semantic Correctness | GPT-3.5 và GPT-4 đạt kết quả tốt nhất | Few-shot prompting required, dataset còn hạn chế |
| Ferreira et al., 2025 (AST) | GPT-4 Turbo | Industrial User Stories | Usefulness, Test Quality | 95% useful scenarios, 92% useful test cases | Single industrial case study |
| Paduraru et al., 2025 | Agentic AI \+ LLM | BDD Scenarios | Automation Effectiveness | Tự động sinh BDD tests hiệu quả | Chưa có đánh giá thực nghiệm lớn |
| Fonseca et al., 2025 (ASE) | AToMIC Framework \+ LLM | BMW MyBMW Application | Gherkin Correctness, Execution Success | 93.3% Gherkin đúng cú pháp, 78.8% Page Objects chạy được, 100% UI Tests chạy thành công | Chỉ đánh giá trên một ứng dụng |
| Santos et al., 2024 | LLM | Proof-of-Concept Projects | Test Coverage | Tăng độ phủ kiểm thử | Quy mô dự án hạn chế |
| Ribeiro dos Santos et al., 2025 (WEBIST) | ChatGPT, Gemini, Grok, GitHub Copilot | BDD Test Scenarios | Coverage, Accuracy, Speed | ChatGPT chính xác nhất, Grok nhanh nhất | Dataset nhỏ |
| Fernandes et al., 2025 (SBES) | GPT-3.5, GPT-4 Turbo, GPT-4o Mini, LLaMA 3, Phi-3, Gemini, DeepSeek R1 | Natural Language Requirements | Gherkin Generation Quality | Gemini cân bằng giữa độ chính xác và ổn định | Chỉ đánh giá trên một số domain |
| Adu (Thesis) | GPT-3.5-Turbo \+ RAG | Software Testing Scenarios | Scenario Quality | RAG cải thiện chất lượng test generation | Prototype học thuật |
| Galloy et al., 2025 (ICSTW) | SELF-INSTRUCT \+ LLM | Synthetic BDD Dataset | Syntax Compliance, Completeness | Chất lượng seed ảnh hưởng mạnh tới syntax compliance | Dataset tổng hợp |
| Nettur et al., 2025 (IEEE Access) | GPT-4o, GPT-4 Turbo | User Stories, Cypress Tests | Completeness, Syntax Errors | GPT-4o few-shot chain cho kết quả tốt nhất | Dataset nhỏ |
| Rahman & Zhu, 2024 | GPT-4 \+ RaT Prompting | 7 Requirements Documents | RUST Survey Evaluation | Khoảng 5% user stories thiếu chi tiết, 1% mơ hồ | Input chỉ dạng văn bản |
| Kavuri, 2022 | GPT-based Models | 120 Requirements | Syntax, Execution, Coverage | GPT-4 đạt chất lượng script cao nhất | Framework đánh giá còn hạn chế |
| Tiwari, 2025 (FECSIT) | Generative AI / LLM | 100 BDD Cases | Time Reduction, Defect Reduction, Coverage | Giảm 40% thời gian, giảm 25% lỗi, tăng 10% coverage | Phụ thuộc chất lượng requirements |
| Jagielski et al., 2025 (GACLM) | Private GPT \+ RAG \+ Gherkin | Hello World, Digit Recognition | Executable Rate, Coverage | Khoảng 95% test executable khi dùng Gherkin | Hiệu quả thấp hơn với ML workflows |
| AutomTest 3.0 | GPT-3.5, PaLM | User Stories | Ease of Use, Coverage | Tự động sinh test cases từ user stories | Chủ yếu hỗ trợ Java |
| GenIA-E2ETest, 2025 | Multi-level Prompting \+ LLM | 2 Web Applications | Precision, Recall | Precision 82%, Recall 85%, Manual Fix \~10% | Nhạy với UI động |
| Kumari, 2025 | GPT-4 \+ Multi-Agent Framework | Structured Requirements | Coverage, Adaptability | Độ phủ cao nhờ cơ chế refinement nhiều vòng | Chi phí tính toán cao |
| Titeev, 2025 | Llama 3.3 70B \+ Playwright \+ POM | 1,232 Web Tests | Success Rate, Time Reduction | Success Rate 81%, giảm thời gian 2–3 lần | POM phức tạp chỉ đạt 37% |
| Yu et al., 2023 (QRS) | ChatGPT (GPT-3.5) \+ Appium | 6 Mobile Applications | Script Generation, Migration Success | Hỗ trợ sinh script đa nền tảng | Giới hạn context và tính ngẫu nhiên |

## **Summary**

* Evidence Table Size (N) \= 19 papers  
* Main LLMs: GPT-3.5, GPT-4, GPT-4 Turbo, GPT-4o, Gemini, Grok, GitHub Copilot, Llama 2, Llama 3, PaLM-2, DeepSeek R1  
* Main Tasks:  
  * Acceptance Test Generation  
  * Gherkin Scenario Generation  
  * BDD Test Automation  
  * User Story to Test Transformation  
  * End-to-End Test Automation  
* Common Metrics:  
  * Syntax Correctness  
  * Semantic Correctness  
  * Coverage  
  * Precision  
  * Recall  
  * Execution Success Rate  
  * Time Reduction  
* Common Limitations:  
  * Small datasets  
  * Single case study evaluations  
  * Dependence on prompt quality  
  * Human validation still required  
  * Limited industrial-scale validation

