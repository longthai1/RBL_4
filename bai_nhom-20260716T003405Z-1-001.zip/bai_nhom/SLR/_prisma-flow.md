# **PRISMA Flow – LLM for Acceptance Test Automation (BDD/Gherkin)**

\[Records identified from database searching (N \= 49)\]  
↓  
\[After duplicate removal (N \= 49)\]  
↓  
Screened by title and abstract (N \= 49\)  
│  
├── Excluded (N \= 19\)  
│ ├── EC-D \= 2  
│ ├── EC-O \= 15  
│ ├── EC-N \= 1  
│ └── EC-G \= 1  
│  
↓  
Papers passing V1 screening (N \= 30\)  
↓  
Full-text assessed for eligibility (N \= 30\)  
│  
├── Excluded after full-text review (N \= 11\)  
│ ├── Not focused on Acceptance Test Automation \= 8  
│ ├── Survey / Roadmap papers \= 2  
│ └── Business Analysis focus only \= 1  
│  
↓  
Final included studies (N \= 19\)

