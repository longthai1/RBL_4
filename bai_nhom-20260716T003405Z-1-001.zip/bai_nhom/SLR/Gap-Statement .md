# **Gap Statement — LLM for Acceptance Test Automation (BDD/Gherkin)**

Evidence table: N \= 3 papers

## **Các khoảng trống phát hiện**

### **GAP-T (Technology)**

Các nghiên cứu hiện tại chủ yếu đánh giá GPT-3.5, GPT-4, GPT-4 Turbo, Llama-2 và PaLM-2. Chưa có nghiên cứu thực nghiệm đầy đủ đánh giá GPT-4o trong bài toán sinh Acceptance Test và Gherkin Scenario từ User Stories.

**Bằng chứng:**

* Karpurapu et al. (2024) sử dụng GPT-3.5, GPT-4, Llama-2-13B và PaLM-2.  
* Ferreira et al. (2025) sử dụng GPT-4 Turbo.  
* Fonseca et al. (2025) sử dụng LLM trong framework AToMIC nhưng không đánh giá GPT-4o.  
* Không có paper nào trong evidence table đánh giá riêng GPT-4o.

### **GAP-M (Metric)**

Phần lớn nghiên cứu đánh giá chất lượng bằng usefulness, correctness hoặc execution success. Chưa có sự thống nhất về metric tự động để đo mức độ tương đồng giữa Gherkin sinh ra và Gherkin chuẩn.

**Bằng chứng:**

* Karpurapu et al. (2024): Syntax Correctness, Semantic Correctness.  
* Ferreira et al. (2025): Usefulness, Test Quality.  
* Fonseca et al. (2025): Gherkin Correctness, Execution Success.  
* Không paper nào sử dụng BLEU, ROUGE hoặc Similarity Score để đánh giá Gherkin generation.

### **GAP-D (Dataset)**

Các nghiên cứu hiện tại sử dụng dataset nội bộ hoặc case study công nghiệp quy mô nhỏ. Chưa có benchmark dataset công khai và chuẩn hóa cho bài toán User Story → Gherkin Scenario Generation.

**Bằng chứng:**

* Karpurapu et al. (2024): Dataset BDD nội bộ.  
* Ferreira et al. (2025): User stories từ một đối tác công nghiệp.  
* Fonseca et al. (2025): BMW MyBMW application.  
* Không có dataset chuẩn công khai được sử dụng xuyên suốt giữa các nghiên cứu.

## **Phát biểu GAP tổng hợp**

Mặc dù nhiều nghiên cứu đã chứng minh khả năng của LLM trong việc tự động sinh Acceptance Tests và Gherkin Scenarios, vẫn còn thiếu các nghiên cứu đánh giá GPT-4o trên bộ dữ liệu chuẩn hóa và sử dụng các metric tự động như BLEU hoặc ROUGE để đo chất lượng sinh Gherkin từ User Stories. Điều này tạo cơ hội nghiên cứu về hiệu quả của GPT-4o trong bài toán User Story-to-Gherkin Generation.

