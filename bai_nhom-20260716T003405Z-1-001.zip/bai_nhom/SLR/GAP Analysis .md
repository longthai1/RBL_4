# **GAP Analysis – LLM-Based Gherkin and BDD Test Generation**

Evidence table: N \\= 13 papers

Date: 2026-06-11

## **Bảng GAP**

| Cột | Phát hiện | Loại GAP | Phản chứng |
| :---: | ----- | ----- | ----- |
| **Tool/LLM** | Hầu hết nghiên cứu sử dụng GPT-3.5, GPT-4, GPT-4 Turbo, Gemini, LLaMA hoặc các mô hình thương mại. Chỉ có 1 nghiên cứu đánh giá GPT-4o Mini và không có nghiên cứu nào đánh giá hệ thống GPT-4o với chiến lược zero-shot trên bài toán sinh Gherkin từ user stories. | GAP-T | ✅ |
| **Metric** | Phần lớn nghiên cứu đánh giá bằng usefulness, syntax correctness, coverage, executable rate hoặc khảo sát chuyên gia. Không có nghiên cứu nào sử dụng BLEU như metric chính để đo độ tương đồng giữa Gherkin sinh ra và ground truth. | GAP-M | ✅ |
| **Dataset** | Các nghiên cứu thường sử dụng bộ dữ liệu nội bộ công ty, case study công nghiệp hoặc số lượng user stories nhỏ (\\\<100 mẫu). Chưa có benchmark công khai được sử dụng rộng rãi cho việc đánh giá Gherkin generation. | GAP-D | ✅ |
| **Limitation** | Nhiều nghiên cứu thừa nhận dataset nhỏ, domain giới hạn hoặc cần human-in-the-loop để đánh giá chất lượng đầu ra. | GAP-S | ✅ |

## **Kiểm tra GAP-T**

### **GAP tuyên bố**

Chưa có nghiên cứu đánh giá GPT-4o zero-shot cho sinh Gherkin từ user stories.

| Paper | Đã làm không? | Ghi chú |
| :---: | ----- | ----- |
| **Karpurapu et al., 2024** | Không | GPT-3.5, GPT-4, Llama-2, PaLM-2 |
| **Ferreira et al., 2025** | Không | GPT-4 Turbo |
| **Fonseca et al., 2025** | Không | LLM không tập trung GPT-4o |
| **Fernandes et al., 2025** | Có một phần | GPT-4o Mini, không phải GPT-4o đầy đủ |
| **Nettur et al., 2025** | Không | GPT-4o hỗ trợ Cypress generation, không đánh giá Gherkin generation |
| **Các paper còn lại** | Không | Không đánh giá GPT-4o |

Kết luận: Xác nhận GAP-T.

## **Kiểm tra GAP-M**

### **GAP tuyên bố**

Chưa có nghiên cứu đánh giá bằng BLEU cho Gherkin generation.

| Paper | Metric |
| :---: | ----- |
| **Karpurapu et al., 2024** | Syntax correctness, semantic correctness |
| **Ferreira et al., 2025** | Usefulness |
| **Fonseca et al., 2025** | Accuracy, execution success |
| **Fernandes et al., 2025** | Correctness, stability |
| **Nettur et al., 2025** | Completeness, syntax errors |
| **Jagielski et al., 2025** | Executable rate, pass rate |
| **GenIA-E2ETest, 2025** | Precision, Recall |
| **Titeev, 2025** | Success rate |
| **Yu et al., 2023** | Migration success |

Kết luận: Không có paper sử dụng BLEU làm metric chính.

→ Xác nhận GAP-M.

## **Kiểm tra GAP-D**

### **GAP tuyên bố**

Dataset công khai và benchmark chuẩn cho Gherkin generation còn thiếu.

| Paper | Dataset |
| :---: | ----- |
| **Karpurapu et al., 2024** | JavaScript functions |
| **Ferreira et al., 2025** | Industrial user stories |
| **Fonseca et al., 2025** | BMW MyBMW project |
| **Jagielski et al., 2025** | Hello World \\+ Digit Recognition |
| **Nettur et al., 2025** | \\\~55 user stories |
| **GeneUS, 2024** | 7 requirements documents |

Kết luận: Hầu hết dataset nhỏ hoặc proprietary.

→ Xác nhận GAP-D.

## **Feasibility Check**

| Tiêu chí | Đánh giá |
| :---: | ----- |
| **Dataset** | 🟢 Có thể sử dụng user stories công khai trên GitHub |
| **Tool/API** | 🟢 GPT-4o có sẵn qua ChatGPT |
| **Compute** | 🟢 CPU hoặc Colab Free đủ |
| **Ground Truth** | 🟢 Có thể xây dựng từ Gherkin hiện có |
| **Skills** | 🟢 Phù hợp với nhóm sinh viên |
| **Time** | 🟢 Hoàn thành trong phạm vi môn học |

## **GAP chính được chọn**

### **GAP-T (Primary)**

Chưa có nghiên cứu đánh giá khả năng sinh Gherkin Acceptance Test từ User Story bằng GPT-4o sử dụng chiến lược zero-shot prompting.

### **GAP-M (Secondary)**

Các nghiên cứu hiện tại chủ yếu đánh giá bằng usefulness, correctness hoặc expert judgement; chưa sử dụng BLEU để đo mức độ tương đồng giữa Gherkin sinh ra và ground-truth Gherkin.

## **Phát biểu GAP tổng hợp**

Mặc dù nhiều nghiên cứu đã sử dụng GPT-3.5, GPT-4, GPT-4 Turbo và các LLM khác để hỗ trợ sinh Gherkin hoặc Acceptance Tests, chưa có nghiên cứu nào đánh giá một cách có hệ thống khả năng của GPT-4o với chiến lược zero-shot prompting trên bài toán sinh Gherkin từ User Stories. Ngoài ra, các nghiên cứu hiện tại chủ yếu sử dụng đánh giá thủ công hoặc syntax-based metrics, trong khi các metric dựa trên độ tương đồng văn bản như BLEU vẫn chưa được khai thác đầy đủ.

Evidence 1 – Karpurapu et al., 2024  
LLM được đánh giá: GPT-3.5, GPT-4, Llama-2, PaLM-2.  
Điểm mạnh của evidence: Đây là nghiên cứu so sánh nhiều LLM nhất cho bài toán sinh test/acceptance scenarios.

Khoảng trống: Hoàn toàn không đánh giá GPT-4o và cũng không nghiên cứu zero-shot GPT-4o.

➡️ Kết luận: Nếu một nghiên cứu benchmark lớn vẫn chưa xét GPT-4o thì đây là bằng chứng rất mạnh cho GAP-T.

Evidence 2 – Fernandes et al., 2025  
LLM được đánh giá: GPT-4o Mini.  
Điểm mạnh của evidence: Là paper duy nhất trong tập nghiên cứu có nhắc đến dòng GPT-4o.

Khoảng trống: Chỉ dùng GPT-4o Mini, không phải GPT-4o đầy đủ, và không tập trung đánh giá Gherkin generation từ User Stories bằng zero-shot prompting.

➡️ Kết luận: Sự xuất hiện của GPT-4o Mini càng làm nổi bật rằng GPT-4o đầy đủ vẫn chưa được nghiên cứu.

Evidence 3 – Nettur et al., 2025  
LLM được sử dụng: GPT-4o.  
Bài toán nghiên cứu: Sinh mã kiểm thử/Cypress automation.

Khoảng trống: Không đánh giá Gherkin generation, không sử dụng User Stories → Gherkin pipeline, và không nghiên cứu zero-shot prompting.

➡️ Kết luận: Dù GPT-4o đã được dùng trong lĩnh vực kiểm thử phần mềm, nó chưa từng được đánh giá cho bài toán Gherkin generation.

