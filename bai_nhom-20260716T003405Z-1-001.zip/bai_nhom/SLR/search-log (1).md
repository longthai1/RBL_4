\# Search Log — LLM-Based Gherkin and BDD Test Generation

\*\*Thành viên:\*\*

\- Đào Thiên Thành

\- Lương Thiện Nhất

\- Thái Thành Long

\*\*Topic:\*\* LLM-Based Gherkin and BDD Test Generation

\*\*Thời gian thực hiện:\*\* 2026-06-01 → 2026-06-08

\---

\# Thành viên 1: Đào Thiên Thành

\#\# Chuỗi tìm kiếm (Query Strings)

\#\#\# String A

("Gherkin" OR "BDD" OR "Behavior-Driven Development")

AND

("LLM" OR "GPT" OR "Large Language Model")

AND

("Test Generation" OR "Test Case Generation")

\*\*Database:\*\* Google Scholar

\*\*Ngày search:\*\* 2026-06-01

\*\*Kết quả:\*\* 13 papers

\#\#\# String B

("Acceptance Test" OR "Behavior Specification")

AND

("ChatGPT" OR "GPT-4")

AND

("Requirements Engineering")

\*\*Database:\*\* Google Scholar

\*\*Ngày search:\*\* 2026-06-01

\*\*Kết quả:\*\* 6 papers

\---

\# Thành viên 2: Lương Thiện Nhất

\#\# Chuỗi tìm kiếm (Query Strings)

\#\#\# String C

("User Story")

AND

("GPT" OR "LLM")

AND

("BDD" OR "Gherkin")

\*\*Database:\*\* semantic schoolar

\*\*Ngày search:\*\* 2026-06-02

\*\*Kết quả:\*\* 10 papers

\#\#\# String D

("Behavior-Driven Development")

AND

("Generative AI")

AND

("Software Testing")

\*\*Database:\*\* semantic schoolar

\*\*Ngày search:\*\* 2026-06-02

\*\*Kết quả:\*\* 12 papers

\---

\# Thành viên 3: Thái Thành Long

\#\# Chuỗi tìm kiếm (Query Strings)

\#\#\# String E

("Large Language Model")

AND

("Test Automation")

AND

("Gherkin Scenario")

\*\*Database:\*\* core

\*\*Ngày search:\*\* 2026-06-03

\*\*Kết quả:\*\* 8 papers

\#\#\# String F

("GPT-4")

AND

("Acceptance Testing")

AND

("User Requirements")

\*\*Database:\*\* core

\*\*Ngày search:\*\* 2026-06-03

\*\*Kết quả:\*\* 0 papers

\---

\# Tổng hợp trước Dedup

| Thành viên | String | Kết quả |

|------------|---------|----------|

| Đào Thiên Thành | A | 13 |

| Đào Thiên Thành | B | 6 |

| Lương Thiện Nhất | C | 10 |

| Lương Thiện Nhất | D | 12 |

| Thái Thành Long | E | 8 |

| Thái Thành Long | F | 0 |

| \*\*Tổng trước dedup\*\* | | \*\*49\*\* |

\---

\# Kết quả sau xử lý

| Mục | Số lượng |

|------|----------|

| Tổng trước dedup | 49 |

| Trùng lặp (duplicate) | 2 |

| Sau dedup | 47 |

| Loại ở V1 Screening | 18 |

| Pass V1 / Full-text assessed | 29 |

| Loại ở Full-text V2 | 15 |

| Final Included Papers | 14 |

\---

\# Ghi chú

\- Tất cả tìm kiếm được thực hiện trên Google Scholar.

\- Chỉ giữ các bài báo tiếng Anh.

\- Chỉ giữ các bài liên quan đến việc sử dụng LLM để sinh Gherkin Scenarios, BDD Specifications hoặc Acceptance Test Cases.

\- Các bài không liên quan đến Software Testing hoặc Requirements Engineering được loại bỏ ở vòng Screening (EC-O).

\- Các bài không có thực nghiệm hoặc không có kết quả định lượng bị loại theo EC-N hoặc IC-E.

\- Quá trình screening được thực hiện theo tiêu chí trong file \`ie\_criteria.md\`.

